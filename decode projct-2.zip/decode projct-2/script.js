function caesarCipher(text, shift) {

    let result = "";

    shift = shift % 26;

    for (let i = 0; i < text.length; i++) {

        let char = text[i];

        if (char >= 'A' && char <= 'Z') {

            let code = char.charCodeAt(0);

            let newCode = ((code - 65 + shift) % 26) + 65;

            result += String.fromCharCode(newCode);

        }

        else if (char >= 'a' && char <= 'z') {

            let code = char.charCodeAt(0);

            let newCode = ((code - 97 + shift) % 26) + 97;

            result += String.fromCharCode(newCode);

        }

        else {

            result += char;

        }
    }

    return result;
}


function encryptText() {

    let text = document.getElementById("textInput").value;

    let shift = parseInt(
        document.getElementById("shiftKey").value
    );

    if (text === "") {

        alert("Please enter some text.");

        return;
    }

    if (isNaN(shift)) {

        alert("Please enter a valid shift key.");

        return;
    }

    let encrypted = caesarCipher(text, shift);

    document.getElementById("encryptedOutput").textContent =
        encrypted;

    document.getElementById("decryptedOutput").textContent =
        "Decrypt the encrypted text using the same shift key.";

}


function decryptText() {

    let text = document.getElementById("textInput").value;

    let shift = parseInt(
        document.getElementById("shiftKey").value
    );

    if (text === "") {

        alert("Please enter encrypted text.");

        return;
    }

    if (isNaN(shift)) {

        alert("Please enter a valid shift key.");

        return;
    }

    let decrypted = caesarCipher(text, -shift);

    document.getElementById("decryptedOutput").textContent =
        decrypted;

}