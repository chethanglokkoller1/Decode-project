function analyzeMessage() {

    const message =
        document.getElementById("message").value.trim();

    if (message === "") {

        alert("Please enter an email or message.");

        return;
    }


    const lowerMessage = message.toLowerCase();


    let redFlags = [];
    let suspiciousKeywords = [];
    let suspiciousLinks = [];


    // Suspicious keywords

    const keywords = [
        "urgent",
        "verify your account",
        "verify account",
        "password",
        "click here",
        "login",
        "confirm your account",
        "account suspended",
        "winner",
        "prize",
        "claim now",
        "limited time",
        "immediately",
        "security alert",
        "otp",
        "bank details"
    ];


    keywords.forEach(function(keyword) {

        if (lowerMessage.includes(keyword)) {

            suspiciousKeywords.push(keyword);
        }

    });


    // Detect URLs

    const urlPattern =
        /(https?:\/\/[^\s]+)/gi;

    const links =
        message.match(urlPattern);


    if (links) {

        suspiciousLinks = links;
    }


    // Red flag analysis

    if (
        lowerMessage.includes("urgent") ||
        lowerMessage.includes("immediately")
    ) {

        redFlags.push(
            "Creates urgency or pressure to act immediately."
        );
    }


    if (
        lowerMessage.includes("password") ||
        lowerMessage.includes("otp") ||
        lowerMessage.includes("bank details")
    ) {

        redFlags.push(
            "Requests sensitive information."
        );
    }


    if (
        lowerMessage.includes("click here") ||
        lowerMessage.includes("login")
    ) {

        redFlags.push(
            "Encourages the recipient to click a link or log in."
        );
    }


    if (
        lowerMessage.includes("winner") ||
        lowerMessage.includes("prize") ||
        lowerMessage.includes("claim now")
    ) {

        redFlags.push(
            "Uses unexpected prize or reward claims."
        );
    }


    if (suspiciousLinks.length > 0) {

        redFlags.push(
            "Contains a link that should be checked carefully before opening."
        );
    }


    // If no red flags

    if (redFlags.length === 0) {

        redFlags.push(
            "No obvious phishing indicators were detected by this basic analyzer."
        );
    }


    // Display result

    const result =
        document.getElementById("result");

    result.classList.remove("hidden");


    // Status

    const status =
        document.getElementById("status");


    if (redFlags.length > 1) {

        status.textContent =
            "⚠️ Potential phishing indicators detected.";

    } else {

        status.textContent =
            "ℹ️ No obvious phishing indicators detected.";

    }


    // Red flags

    const redFlagList =
        document.getElementById("redFlags");

    redFlagList.innerHTML = "";


    redFlags.forEach(function(flag) {

        const li = document.createElement("li");

        li.textContent = flag;

        redFlagList.appendChild(li);

    });


    // Links

    const linkList =
        document.getElementById("links");

    linkList.innerHTML = "";


    if (suspiciousLinks.length === 0) {

        const li = document.createElement("li");

        li.textContent =
            "No links detected.";

        linkList.appendChild(li);

    } else {

        suspiciousLinks.forEach(function(link) {

            const li = document.createElement("li");

            li.textContent = link;

            linkList.appendChild(li);

        });

    }


    // Keywords

    const keywordList =
        document.getElementById("keywords");

    keywordList.innerHTML = "";


    if (suspiciousKeywords.length === 0) {

        const li = document.createElement("li");

        li.textContent =
            "No suspicious keywords detected.";

        keywordList.appendChild(li);

    } else {

        suspiciousKeywords.forEach(function(keyword) {

            const li = document.createElement("li");

            li.textContent = keyword;

            keywordList.appendChild(li);

        });

    }


    // Explanation

    const explanation =
        document.getElementById("explanation");


    if (redFlags.length > 1) {

        explanation.textContent =
            "The message contains one or more characteristics commonly associated with phishing, such as urgency, requests for sensitive information, suspicious links, or unexpected rewards. The recipient should verify the sender and destination independently before taking any action.";

    } else {

        explanation.textContent =
            "This basic analyzer did not identify obvious phishing indicators. However, this does not guarantee that the message is safe. The sender, links, context, and requested actions should still be verified.";

    }

}